%====================================================================================
% Context ctxAnotherSensorEmitter  SYSTEM-configuration: file it.unibo.ctxAnotherSensorEmitter.sonarSensorEmitter.pl 
%====================================================================================
context(ctxanothersensoremitter, "localhost",  "TCP", "5023" ).  		 
%%% -------------------------------------------
qactor( anothersensorsonar , ctxanothersensoremitter, "it.unibo.anothersensorsonar.MsgHandle_Anothersensorsonar"   ). %%store msgs 
qactor( anothersensorsonar_ctrl , ctxanothersensoremitter, "it.unibo.anothersensorsonar.Anothersensorsonar"   ). %%control-driven 
%%% -------------------------------------------
%%% -------------------------------------------

