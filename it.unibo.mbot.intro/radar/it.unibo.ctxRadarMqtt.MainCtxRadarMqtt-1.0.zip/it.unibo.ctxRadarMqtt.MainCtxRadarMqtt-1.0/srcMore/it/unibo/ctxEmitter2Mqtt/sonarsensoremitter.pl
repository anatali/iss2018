%====================================================================================
% Context ctxEmitter2Mqtt  SYSTEM-configuration: file it.unibo.ctxEmitter2Mqtt.sonarSensorEmitter.pl 
%====================================================================================
context(ctxemitter2mqtt, "localhost",  "TCP", "5023" ).  		 
%%% -------------------------------------------
qactor( anothersensorsonar , ctxemitter2mqtt, "it.unibo.anothersensorsonar.MsgHandle_Anothersensorsonar"   ). %%store msgs 
qactor( anothersensorsonar_ctrl , ctxemitter2mqtt, "it.unibo.anothersensorsonar.Anothersensorsonar"   ). %%control-driven 
%%% -------------------------------------------
%%% -------------------------------------------

