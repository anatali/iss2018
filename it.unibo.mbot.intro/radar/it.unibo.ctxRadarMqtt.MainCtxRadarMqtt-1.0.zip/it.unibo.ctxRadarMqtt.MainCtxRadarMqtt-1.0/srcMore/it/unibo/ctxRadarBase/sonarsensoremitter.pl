%====================================================================================
% Context ctxRadarBase standalone= SYSTEM-configuration: file it.unibo.ctxRadarBase.sonarSensorEmitter.pl 
%====================================================================================
context(ctxradarbase, "localhost",  "TCP", "8080" ).  		 
%%% -------------------------------------------
