%====================================================================================
% Context ctxRadarMqtt  SYSTEM-configuration: file it.unibo.ctxRadarMqtt.radarguimqtt.pl 
%====================================================================================
context(ctxradarmqtt, "192.168.0.104",  "TCP", "8033" ).  		 
%%% -------------------------------------------
qactor( radarguimqtt , ctxradarmqtt, "it.unibo.radarguimqtt.MsgHandle_Radarguimqtt"   ). %%store msgs 
qactor( radarguimqtt_ctrl , ctxradarmqtt, "it.unibo.radarguimqtt.Radarguimqtt"   ). %%control-driven 
qactor( testermqtt , ctxradarmqtt, "it.unibo.testermqtt.MsgHandle_Testermqtt"   ). %%store msgs 
qactor( testermqtt_ctrl , ctxradarmqtt, "it.unibo.testermqtt.Testermqtt"   ). %%control-driven 
%%% -------------------------------------------
eventhandler(evh,ctxradarmqtt,"it.unibo.ctxRadarMqtt.Evh","alarm").  
%%% -------------------------------------------

