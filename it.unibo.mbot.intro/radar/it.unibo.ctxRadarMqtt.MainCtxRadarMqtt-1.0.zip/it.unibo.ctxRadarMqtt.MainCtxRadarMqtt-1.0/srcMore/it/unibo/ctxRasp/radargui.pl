%====================================================================================
% Context ctxRasp  SYSTEM-configuration: file it.unibo.ctxRasp.radargui.pl 
%====================================================================================
context(ctxradarbase, "192.168.137.1",  "TCP", "8033" ).  		 
context(ctxrasp, "192.168.137.2",  "TCP", "8043" ).  		 
%%% -------------------------------------------
qactor( radarguibase , ctxradarbase, "it.unibo.radarguibase.MsgHandle_Radarguibase"   ). %%store msgs 
qactor( radarguibase_ctrl , ctxradarbase, "it.unibo.radarguibase.Radarguibase"   ). %%control-driven 
qactor( tester , ctxrasp, "it.unibo.tester.MsgHandle_Tester"   ). %%store msgs 
qactor( tester_ctrl , ctxrasp, "it.unibo.tester.Tester"   ). %%control-driven 
%%% -------------------------------------------
eventhandler(evh,ctxrasp,"it.unibo.ctxRasp.Evh","alarm").  
%%% -------------------------------------------

